/***************************************************************************//**
 * @file memlcd_app.h
 * @brief Memory Liquid Crystal Display (LCD) example functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

#ifndef MEMLCD_APP_H
#define MEMLCD_APP_H

/***************************************************************************//**
 * Initialize example
 ******************************************************************************/

#define   DISP_CENTER       64
void memlcd_app_init(void);
void lcd_clear(void);
void lcd_print_text(char * str);
void update_lcd(void);
void lcd_landing(void);
void lcd_polygon(uint32_t num_points, const int32_t *points);
#endif // MEMLCD_APP_H
