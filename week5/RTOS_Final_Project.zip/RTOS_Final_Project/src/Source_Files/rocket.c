/*
 * rocket.c
 *
 *  Created on: Nov 3, 2021
 *      Author: maxpettit
 */


#include "rocket.h"


static OS_MUTEX FUEL_LOCK;
static OS_MUTEX ANGLE_LOCK;
static OS_MUTEX ROCKET_LOCK;

static OS_TMR tmr_pwm0, tmr_pwm1;   // timers for led periodicity
static OS_TMR tmr_dc0, tmr_dc1;     // timers for led duty cycle

static ANGLE_STRUCT ANGLE_DATA;
static FUEL_STRUCT FUEL_DATA;
static ROCKET_STRUCT  ROCKET_DATA;

static int angle_quanta;

static void led_on_cb(OS_TMR * p_tmr, void * p_arg);
static void led_off_cb(OS_TMR * p_tmr, void * p_arg);

void init_angle(void){
  RTOS_ERR err;
  OSMutexCreate(&ANGLE_LOCK,
                "Angle Mutex",
                &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  ANGLE_DATA.angle = 0;
}

void init_quanta(int quanta){
  angle_quanta = quanta;
}

void init_fuel(void){
  RTOS_ERR err;
  OSMutexCreate(&FUEL_LOCK,
                "Fuel Mutex",
                &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  FUEL_DATA.fuel_rate = 0;
}

void init_rocket(void){
  RTOS_ERR err;
  OSMutexCreate(&ROCKET_LOCK,
                "Rocket Mutex",
                &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

void angle_increment(void){
  RTOS_ERR err;
  OSMutexPend (&ANGLE_LOCK,
               0,
               OS_OPT_PEND_BLOCKING,
               (CPU_TS *)0,
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  ANGLE_DATA.angle += angle_quanta;

  OSMutexPost (&ANGLE_LOCK,
               OS_OPT_POST_NONE,
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

}

void angle_set(int angle){
  RTOS_ERR err;
  OSMutexPend (&ANGLE_LOCK,
               0,
               OS_OPT_PEND_BLOCKING,
               (CPU_TS *)0,
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  ANGLE_DATA.angle = angle;

  OSMutexPost (&ANGLE_LOCK,
               OS_OPT_POST_NONE,
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

void angle_decrement(void){
  RTOS_ERR err;
  OSMutexPend (&ANGLE_LOCK,
               0,
               OS_OPT_PEND_BLOCKING,
               (CPU_TS *)0,
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  ANGLE_DATA.angle -= angle_quanta;

  OSMutexPost (&ANGLE_LOCK,
               OS_OPT_POST_NONE,
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

int angle_get(void){
  RTOS_ERR err;
  int rv;
  OSMutexPend (&ANGLE_LOCK,
               0,
               OS_OPT_PEND_BLOCKING,
               (CPU_TS *)0,
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  rv = ANGLE_DATA.angle;

  OSMutexPost (&ANGLE_LOCK,
               OS_OPT_POST_NONE,
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  return rv;
}

void fuel_set(uint32_t pos){
  RTOS_ERR err;
  OSMutexPend (&FUEL_LOCK,
               0,
               OS_OPT_PEND_BLOCKING,
               (CPU_TS *)0,
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  FUEL_DATA.fuel_rate = pos;

  OSMutexPost (&FUEL_LOCK,
               OS_OPT_POST_NONE,
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

}

int fuel_get(void){
  RTOS_ERR err;
  uint32_t rv;
  OSMutexPend (&FUEL_LOCK,
               0,
               OS_OPT_PEND_BLOCKING,
               (CPU_TS *)0,
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  rv = FUEL_DATA.fuel_rate;

  OSMutexPost (&FUEL_LOCK,
               OS_OPT_POST_NONE,
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  return rv;
}

// calculate vertices based on input rocket, store in poly
void get_vertices(POLYGON_STRUCT * poly, ROCKET_STRUCT *rocket){
  int x = rocket->x_loc;
  int y = rocket->y_loc;
  int angle = rocket->angle;

  double alpha = asin((double)SHIP_HLF_WIDTH/(double)SHIP_SIDE_LEN);    // move to a rocket init function and alpha is a static var
  double ang = angle * PI/180;
  poly->vf_x = x;
  poly->vf_y = y;
  poly->vL_x = round(sin(ang - alpha)*SHIP_SIDE_LEN + x);
  poly->vL_y = round(-1*cos(ang - alpha)*SHIP_SIDE_LEN + y);
  poly->vR_x = round(sin(ang + alpha)*SHIP_SIDE_LEN + x);
  poly->vR_y = round(-1*cos(ang + alpha)*SHIP_SIDE_LEN + y);
}


void led_on_cb(OS_TMR * p_tmr, void * p_arg){
  RTOS_ERR err;
  OS_TMR *dc_tmr;
  int dc;

  dc = (int)p_arg;

  if(p_tmr == &tmr_pwm0){
      GPIO_PinOutSet(LED0_port, LED0_pin);
      dc_tmr = &tmr_dc0;
  }
  else if (p_tmr == &tmr_pwm1){
      GPIO_PinOutSet(LED1_port, LED1_pin);
      dc_tmr = &tmr_dc1;
  } else return;

  OSTmrSet(dc_tmr,
           dc,             // delay from p_arg
           0,             // period
           (OS_TMR_CALLBACK_PTR) led_off_cb,
           NULL,
           &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));


  OSTmrStart(dc_tmr, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}


void led_off_cb(OS_TMR * p_tmr, void * p_arg){
  PP_UNUSED_PARAM(p_arg);
  if(p_tmr == &tmr_dc0){
      GPIO_PinOutClear(LED0_port, LED0_pin);
  }
  else if (p_tmr == &tmr_dc1){
      GPIO_PinOutClear(LED1_port, LED1_pin);
  }
  else return;
}


void pwm_init(void){
  RTOS_ERR err;

  // Periodic timers
  OSTmrCreate(&tmr_pwm0,
              "PWM Timer 0",
              0,                      // 0 delay
              PWM_PERIOD0,
              OS_OPT_TMR_PERIODIC,
              (OS_TMR_CALLBACK_PTR) led_on_cb,
              NULL,
              &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTmrCreate(&tmr_pwm1,
              "PWM Timer 1",
              0,                      // 0 delay
              PWM_PERIOD0,
              OS_OPT_TMR_PERIODIC,
              (OS_TMR_CALLBACK_PTR) led_on_cb,
              NULL,
              &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));


  // Duty Cycle timers
  OSTmrCreate(&tmr_dc0,
              "DC Timer 0",
              1,                      // dealy
              0,                      // 0 period
              OS_OPT_TMR_ONE_SHOT,
              (OS_TMR_CALLBACK_PTR) led_on_cb,
              NULL,
              &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTmrCreate(&tmr_dc1,
              "DC Timer 1",
              1,                      // delay
              0,                      // 0 period
              OS_OPT_TMR_ONE_SHOT,
              (OS_TMR_CALLBACK_PTR) led_on_cb,
              NULL,
              &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  // create timers just once
  // start timers
  // use OSTmrSet() to reconfigure


}

void pwm_stop(int sel){
  RTOS_ERR err;
  OS_TMR *tmr;

  if(sel == 0) tmr = &tmr_pwm0;
  else if(sel == 1) tmr = &tmr_pwm1;
  else return;
  OSTmrStop(tmr,
            OS_OPT_TMR_NONE,
            (void *) NULL,
            &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

void pwm_start(int sel, int per, int dc){
  RTOS_ERR err;
  OS_TMR *tmr;

  if(sel == 0) tmr = &tmr_pwm0;
  else if(sel == 1) tmr = &tmr_pwm1;
  else return;


  OSTmrSet(tmr,
           0,             // delay from p_arg
           per,          // period
           (OS_TMR_CALLBACK_PTR) led_on_cb,
           (void *) dc,
           &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));


  OSTmrStart(tmr, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

void pwm_set(int sel, int per, int dc){
  RTOS_ERR err;
  OS_TMR *tmr;

  if(sel == 0) tmr = &tmr_pwm0;
  else if(sel == 1) tmr = &tmr_pwm1;
  else return;


  OSTmrSet(tmr,
           0,             // delay from p_arg
           per,          // period
           (OS_TMR_CALLBACK_PTR) led_on_cb,
           (void *) dc,
           &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

void disp_rocket(POLYGON_STRUCT * poly){
  int32_t points[2*SHIP_NUM_PTS];
  points[0] = poly->vf_x;
  points[1] = poly->vf_y;

  points[2] = poly->vL_x;
  points[3] = poly->vL_y;

  points[4] = poly->vR_x;
  points[5] = poly->vR_y;

  lcd_clear();

  if(get_gameover()){
      if(get_win()) disp_win(true);
      else disp_win(false);
  }

  lcd_polygon(SHIP_NUM_PTS, points);

  // Draw landing spot
  lcd_landing();

  update_lcd();
}

ROCKET_STRUCT get_rocket(void){
  ROCKET_STRUCT temp;
  RTOS_ERR err;

  OSMutexPend (&ROCKET_LOCK,
               0,
               OS_OPT_PEND_BLOCKING,
               (CPU_TS *)0,
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  temp.angle = ROCKET_DATA.angle;
  temp.x_loc = ROCKET_DATA.x_loc;
  temp.y_loc = ROCKET_DATA.y_loc;

  OSMutexPost (&ROCKET_LOCK,
               OS_OPT_POST_NONE,
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  return temp;
}

void set_rocket(ROCKET_STRUCT *input){
  RTOS_ERR err;

  OSMutexPend (&ROCKET_LOCK,
               0,
               OS_OPT_PEND_BLOCKING,
               (CPU_TS *)0,
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  ROCKET_DATA.angle = input->angle;
  ROCKET_DATA.x_loc = input->x_loc;
  ROCKET_DATA.y_loc = input->y_loc;

  OSMutexPost (&ROCKET_LOCK,
               OS_OPT_POST_NONE,
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

void disp_win(bool win){
  if(win) lcd_print_text("You Win!");
  else lcd_print_text("You Lose!");
  lcd_print_text("Press a button\nto reset game");
}

