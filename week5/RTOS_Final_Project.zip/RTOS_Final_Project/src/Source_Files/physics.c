/*
 * physics.c
 *
 *  Created on: Nov 5, 2021
 *      Author: maxpettit
 */


#include "physics.h"


static volatile uint32_t msTicks;
static CONFIG_STRUCT configuration;
static int fuel_tank;
static int velx, vely;
static bool gameover;
static bool blackout_pause;
static OS_TMR tmr_blackout;

static void blackout_toggle(void);

/***************************************************************************//**
 * @brief
 *      Interrupt handler for SysTick Timer.
 *
 * @details
 *      Increments tick counter. If using interrupts, sample touch sensor and
 *      drive LEDs every 100ms.
 *
 ******************************************************************************/
void SysTick_Handler(void){
  msTicks++;
}


void blackout_toggle(void){
  blackout_pause = false;
}
//**********************************************************
// Physics INIT
// Set up rocket starting position
// Initialize fuel
// Initialize angle_quanta
//**********************************************************
void physics_init(void){
  ROCKET_STRUCT rocket;
  RTOS_ERR err;
  blackout_pause = false;


  init_rocket();
  angle_set(0);
  gameover = false;
  int temp;

  // if init pos == -1 generate random
  temp = configuration.init_xpos;
  if(temp < 0){
      temp = (rand() % RAND_RANGE) + DISP_CENTER/2;
  }

  rocket.x_loc = temp;
  rocket.y_loc = YSTART;
  rocket.angle = 0;

  // create blackout timer
  OSTmrCreate(&tmr_blackout,
              "Blackout Timer",
              configuration.black_dur,                      // 0 delay
              0,
              OS_OPT_TMR_ONE_SHOT,
              (OS_TMR_CALLBACK_PTR) blackout_toggle,
              NULL,
              &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));


  set_rocket(&rocket);
  init_quanta(configuration.angle_quanta);
  fuel_tank = configuration.init_fuel;

  // if init vel == -1 generate random
  temp = configuration.xvel;
  if(temp < 0){
      temp = (rand() % RAND_RANGE) - RAND_RANGE/2;
  }
  velx = temp;
  vely = configuration.yvel;

  pwm_start(LED0_SEL, 5, 5);
  pwm_start(LED1_SEL, 10, 5);
}



//**********************************************************
// Physics Engine
// Runs every tau_phys
// Calculate force from thrust
// Use kinematic equations for movement of rocket
// Check blackout
// Check win/loss
//**********************************************************
void physics_engine(void){
  ROCKET_STRUCT rocket;
  RTOS_ERR err;
  bool win;
  int angle, fuel_rate;
  int x, y;
  bool blackout;
  int thrust, pwm0, pwm1;
  float thrustx, thrusty;
  float ts = (float)configuration.tau_phys/10;
  double ang;


  float accx, accy;
  float Fnetx, Fnety;


  angle = angle_get();
  fuel_rate = fuel_get();

  rocket = get_rocket();

  // do something with thrust and fuel rate
  if(blackout_pause){
      thrust = 0;
  } else {
      thrust = calc_thrust(fuel_rate);
  }
  ang = angle * PI/180;
  thrustx = thrust * sin(ang);
  thrusty = thrust * cos(ang);

  // memory (not new acc every time right?)
  Fnetx = thrustx;
  Fnety = thrusty - (configuration.vehicle_mass * configuration.gravity);

  accx = Fnetx / (int)configuration.vehicle_mass;
  accy = Fnety / (int)configuration.vehicle_mass;

  blackout = get_blackout(thrust);


  // calculate change in x and y
  // v = v0 + a*t
  // p = p0+ v0*t + 0.5*a*t^2

  velx += round(accx*ts);
  vely += round(accy*ts);


  x = rocket.x_loc + (velx * ts);
  y = rocket.y_loc - (vely * ts);     // minus bc top is 0


  // math for pwm
  // take a constant, divide by (pwm + 1) set freq to this and dc to .5 of that
  pwm0 = (thrust * 100 / configuration.max_thrust);
  pwm0 = PWM_DEFAULT - ((PWM_DEFAULT-2)*pwm0/100);



  pwm1 = (thrust * 100 / (int)configuration.vehicle_mass) / configuration.black_acc;
  pwm1 = PWM_DEFAULT - ((PWM_DEFAULT-2)*pwm1/100);
//  pwm1 = PWM_DEFAULT;

  if(blackout){
      blackout_pause = true;
      OSTmrStart(&tmr_blackout, &err);
      EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  }

  if(blackout_pause) pwm_set(LED1_SEL, 30, 15);
  else pwm_set(LED1_SEL, pwm1, pwm1/2); // blackout acc as % of blackout

  pwm_set(LED0_SEL, pwm0, pwm0/2);

  // Check for win or loss
  if( x < configuration.xmin || x > configuration.xmax){
      win = false;
      gameover = true;
  }

  if(y >= 125){

      if(abs(vely) > (int)configuration.maxspeedy){
          win = false;
      }
      else if(x > DISP_CENTER + LANDING_RANGE || x < DISP_CENTER - LANDING_RANGE){
          win = false;
      }
      else if(angle != 0) win = false;
      else win = true;

      y = 125;
      gameover = true;
  }


  if(gameover){
      pwm_set(LED0_SEL, 10, 10);
      pwm_set(LED1_SEL, 10, 5);
      set_win(win);
      set_gameover(true);
  }

  rocket.x_loc = x;
  rocket.y_loc = y;
  rocket.angle = angle;

  set_rocket(&rocket);
}

uint32_t get_ticks(void){
  return msTicks;
}

int calc_thrust(int fuel_rate){
  int temp;
  int fuel_consumed;

  fuel_consumed = fuel_rate*FUEL_WEIGHT;

  // drain fuel
  if(fuel_tank < fuel_consumed){
      fuel_rate = fuel_tank;
      fuel_tank = 0;
  } else fuel_tank -= fuel_consumed;

  // to get force fuel_rate needs units kg
  temp = fuel_consumed * configuration.conv_eff;


  return temp;
}

bool get_blackout(int thrust){
  int acc;
  acc = thrust/(int)configuration.vehicle_mass;
  if(acc >= (int)configuration.black_acc) return true;
  return false;
}

void load_config(void){

  // for now load default configuration
  configuration.angle_quanta = ANGLE_DELTA;
  configuration.black_acc = 70;             // 70 = fighter pilot levels
  configuration.black_dur = 10;
  configuration.conv_eff = 4000;            // 4000 standard
  configuration.gravity = 10;
  configuration.init_fuel = 10000;
  configuration.init_xpos = -1;             // if < 0 generate random
  configuration.max_thrust = 160000;        // more research needed
  configuration.maxspeedx = 100;            // adjusts max landing speed
  configuration.maxspeedy = 50;
  configuration.option = option0;
  configuration.tau_phys = 1;               // not used yet
  configuration.vehicle_mass = 6000;        // estimate around 6000kg
  configuration.version = 2;
  configuration.xmax = 130;                 // just outside lcd
  configuration.xmin = -2;                  // just outside lcd
  configuration.xvel = -1;                  // if < 0 generate random
  configuration.yvel = 0;                   // default 0

  return;
}

void game_reset(void){
  set_gameover(false);
  physics_init();
}

CONFIG_STRUCT *get_config(void){
  return &configuration;
}
