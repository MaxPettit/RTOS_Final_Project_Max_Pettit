/**
 * @file gpio.c
 * @author Max Pettit
 * @date September 10, 2021
 * @brief GPIO specific functions
 *
 */

//***********************************************************************************
// Include files
//***********************************************************************************
#include "gpio.h"

//***********************************************************************************
// defined files
//***********************************************************************************


//***********************************************************************************
// global variables
//***********************************************************************************


//***********************************************************************************
// function prototypes
//***********************************************************************************


//***********************************************************************************
// functions
//***********************************************************************************

/***************************************************************************//**
 * @brief
 *    Configures the gpio pins for LEDs
 *
 * @details
 *   sets up drivestrength and pin modes for LED GPIOs
 *
 * @note
 *    specific to led task
 *
 ******************************************************************************/
void gpio_led_open(void){
  // Set LED ports to be standard output drive with default off (cleared)
//  GPIO_DriveStrengthSet(LED0_port, gpioDriveStrengthStrongAlternateStrong);
  GPIO_DriveStrengthSet(LED0_port, gpioDriveStrengthWeakAlternateWeak);
  GPIO_PinModeSet(LED0_port, LED0_pin, gpioModePushPull, LED0_default);

//  GPIO_DriveStrengthSet(LED1_port, gpioDriveStrengthStrongAlternateStrong);
  GPIO_DriveStrengthSet(LED1_port, gpioDriveStrengthWeakAlternateWeak);
  GPIO_PinModeSet(LED1_port, LED1_pin, gpioModePushPull, LED1_default);
}


/***************************************************************************//**
 * @brief
 *    Configures the gpio pins for Buttons
 *
 * @details
 *   sets up pin modes for Button GPIOs
 *
 * @note
 *    specific to button task
 *
 ******************************************************************************/
void gpio_button_open(void){
  /* Configure BTN0 as input and enable interrupt  */
    GPIO_PinModeSet(BTN_PORT, BTN0_PIN, gpioModeInputPull, 1);

    /* Configure BTN1 as input and enable interrupt */
    GPIO_PinModeSet(BTN_PORT, BTN1_PIN, gpioModeInputPull, 1);

    GPIO_IntConfig(BTN_PORT, BTN0_PIN, true, true, true);
     GPIO_IntConfig(BTN_PORT, BTN1_PIN, true, true, true);

     NVIC_EnableIRQ(GPIO_EVEN_IRQn);
     NVIC_EnableIRQ(GPIO_ODD_IRQn);
}
