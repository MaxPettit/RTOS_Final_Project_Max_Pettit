/*
 * vehicle.c
 *
 *  Created on: Oct 15, 2021
 *      Author: maxpettit
 */

#include "vehicle.h"

static struct node_t * BTN_HEAD;

//static bool BTN0_STATE;
//static bool BTN1_STATE;



/***************************************************************************//**
 *
 *
 *
 ******************************************************************************/
void fifo_push(bool btn0, bool btn1){

  // Protect Access to fifo
  CORE_DECLARE_IRQ_STATE;
  CORE_ENTER_CRITICAL();
  push(&BTN_HEAD, btn0, btn1);
  CORE_EXIT_CRITICAL();
}

/***************************************************************************//**
 *
 *
 *
 ******************************************************************************/
uint32_t fifo_read(void){
  uint32_t val;

  // Protect Access to fifo
  CORE_DECLARE_IRQ_STATE;
  CORE_ENTER_CRITICAL();
  val = pop(&BTN_HEAD);
  CORE_EXIT_CRITICAL();
  return val;
}


