/*
 * fifo.c
 *
 *  Created on: Oct 15, 2021
 *      Author: maxpettit
 */

#include "fifo.h"



/***************************************************************************//**
 * @brief
 *      Creates Queue
 *
 * @details
 *      Returns head to new empty queue
 *
 *
 ******************************************************************************/
struct node_t* create_queue(void) {
    struct node_t * head = NULL;
    // return head of new queue
    return head;
}

/***************************************************************************//**
 * @brief
 *      Creates new node
 *
 * @details
 *      Takes boolean of each button to add to node
 *
 *
 ******************************************************************************/
struct node_t* create_new_node(bool btn0, bool btn1) {
    // malloc new node
    struct node_t* new = (struct node_t*)malloc(sizeof(struct node_t));
    new->next = NULL;
    new->btn0 = btn0;
    new->btn1 = btn1;
    return new;
}

/***************************************************************************//**
 * @brief
 *      Peek at fifo head
 *
 ******************************************************************************/
uint32_t peek(struct node_t** head) {
    return (*head)->btn0 * FIFO_BTN0 | (*head)->btn1 * FIFO_BTN1;
}


/***************************************************************************//**
 * @brief
 *      Pops from head of fifo
 *
 * @details
 *      returns value popped
 *
 * @note
 *      value popped is the two booleans of the node ORed together into a
 *      single int. Bit 0 = button 0, Bit 1 = button 1.
 *
 ******************************************************************************/
uint32_t pop(struct node_t** head) {
    uint32_t val;
    if(!(*head)) return 0;
    struct node_t* tmp = *head;
    *head = (*head)->next;
    val = (tmp->btn0 * FIFO_BTN0) | (tmp->btn1 * FIFO_BTN1);
    free(tmp);
    return val;
}

/***************************************************************************//**
 * @brief
 *      push to fifo
 *
 * @details
 *      takes fifo head and bool value for each buttons
 *
 ******************************************************************************/
void push(struct node_t** head, bool btn0, bool btn1) {
    struct node_t *curr, *tmp;
    curr = *head;

    tmp = create_new_node(btn0, btn1);
    if(is_empty(head)){
        *head = tmp;
        return;

    }
    while(curr->next){
        curr = curr->next;
    }
    curr->next = tmp;
}

/***************************************************************************//**
 * @brief
 *      check if fifo is empty
 *
 ******************************************************************************/
int is_empty(struct node_t** head) {
    if(!(*head)){
        return 1;
    }
    return 0;
}


/***************************************************************************//**
 * @brief
 *      Remove all elements from fifo
 *
 ******************************************************************************/
void empty_queue(struct node_t** head) {
    while(!is_empty(head)){
        pop(head);
    }
}
