/*
 * physics.c
 *
 *  Created on: Nov 5, 2021
 *      Author: maxpettit
 */


#include "physics.h"


static volatile uint32_t msTicks;
static CONFIG_STRUCT configuration;
static int fuel_tank;
static int velx, vely;

/***************************************************************************//**
 * @brief
 *      Interrupt handler for SysTick Timer.
 *
 * @details
 *      Increments tick counter. If using interrupts, sample touch sensor and
 *      drive LEDs every 100ms.
 *
 ******************************************************************************/
void SysTick_Handler(void){
  msTicks++;
}

//**********************************************************
// Physics INIT
// Set up rocket starting position
// Initialize fuel
// Initialize angle_quanta
//**********************************************************
void physics_init(void){
  ROCKET_STRUCT rocket;

  init_rocket();
  angle_set(0);

  int temp;

  // if init pos == -1 generate random
  temp = configuration.init_xpos;
  if(temp < 0){
      temp = (rand() % RAND_RANGE) + DISP_CENTER/2;
  }

  rocket.x_loc = temp;
  rocket.y_loc = YSTART;
  rocket.angle = 0;

  set_rocket(&rocket);
  init_quanta(configuration.angle_quanta);
  fuel_tank = configuration.init_fuel;

  // if init vel == -1 generate random
  temp = configuration.xvel;
  if(temp < 0){
      temp = (rand() % RAND_RANGE) - RAND_RANGE/2;
  }
  velx = temp;
  vely = configuration.yvel;
}

//**********************************************************
// Physics Engine
// Runs every tau_phys
// Calculate force from thrust
// Use kinematic equations for movement of rocket
// Check blackout
// Check win/loss
//**********************************************************
void physics_engine(void){
  ROCKET_STRUCT rocket;
  bool win;
  int angle, fuel_rate;
  int x, y;
  bool blackout;
  int thrust;
  float thrustx, thrusty;
  float ts = (float)configuration.tau_phys/10;
  double ang;


  float accx, accy;
  float Fnetx, Fnety;


  angle = angle_get();
  fuel_rate = fuel_get();

  rocket = get_rocket();

  // do something with thrust and fuel rate
  thrust = calc_thrust(fuel_rate);

  ang = angle * PI/180;
  thrustx = thrust * sin(ang);
  thrusty = thrust * cos(ang);

  // memory (not new acc every time right?)
  Fnetx = thrustx;
  Fnety = thrusty - (configuration.vehicle_mass * configuration.gravity);

  accx = Fnetx / (int)configuration.vehicle_mass;
  accy = Fnety / (int)configuration.vehicle_mass;

  blackout = get_blackout(thrust);

  // math section
  // calculate change in x and y

  // v = v0 + a*t
  // p = p0+ v0*t + 0.5*a*t^2

  velx += round(accx*ts);
  vely += round(accy*ts);


  x = rocket.x_loc + (velx * ts);
  y = rocket.y_loc - (vely * ts);     // minus bc top is 0


  // at the end of the math do the following


  // Check for win or loss
  if( x < configuration.xmin || x > configuration.xmax){
      win = false;
      set_win(win);
      set_gameover(true);
  }

  // Add game over boolean to rocket struct, add win loss to rocket struct
  // so display task can handle that
  if(y >= 125){

      if(abs(vely) > (int)configuration.maxspeedy){
          win = false;
      }
      else if(x > DISP_CENTER + LANDING_RANGE || x < DISP_CENTER - LANDING_RANGE){
          win = false;
      }
      else if(angle != 0) win = false;
      else win = true;

      y = 125;
      set_win(win);
      set_gameover(true);
  }


  rocket.x_loc = x;
  rocket.y_loc = y;
  rocket.angle = angle;

  set_rocket(&rocket);
}

uint32_t get_ticks(void){
  return msTicks;
}

int calc_thrust(int fuel_rate){
  int temp;
  int fuel_consumed;

  fuel_consumed = fuel_rate*FUEL_WEIGHT;

  // drain fuel
  if(fuel_tank < fuel_consumed){
      fuel_rate = fuel_tank;
      fuel_tank = 0;
  } else fuel_tank -= fuel_consumed;

  // to get force fuel_rate needs units kg
  temp = fuel_consumed * configuration.conv_eff;


  return temp;
}

bool get_blackout(int acc){
  if(acc >= (int)configuration.black_acc) return true;
  return false;
}

void load_config(void){

  // for now load default configuration
  configuration.angle_quanta = ANGLE_DELTA;
  configuration.black_acc = 1000;           // more research needed
  configuration.black_dur = 10;
  configuration.conv_eff = 4000;            // 4000 standard
  configuration.gravity = 10;
  configuration.init_fuel = 10000;
  configuration.init_xpos = -1;             // if < 0 generate random
  configuration.max_thrust = 10;            // more research needed
  configuration.maxspeedx = 100;            // adjusts max landing speed
  configuration.maxspeedy = 50;
  configuration.option = option0;
  configuration.tau_phys = 1;               // not used yet
  configuration.vehicle_mass = 6000;        // estimate around 4000kg
  configuration.version = 2;
  configuration.xmax = 130;                 // just outside lcd
  configuration.xmin = -2;                  // just outside lcd
  configuration.xvel = -1;                  // if < 0 generate random
  configuration.yvel = 0;                   // default 0

  return;
}

void game_reset(void){
  set_gameover(false);
  physics_init();
}

CONFIG_STRUCT *get_config(void){
  return &configuration;
}
