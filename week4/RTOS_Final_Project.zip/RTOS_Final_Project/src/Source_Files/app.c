/***************************************************************************//**
 * @file app.c
 * @brief Top level application functions
 * @author Max Pettit
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/
#include "app.h"

#define tests_on

/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/

static OS_TCB angle_tcb, throttle_tcb, led_tcb, lcd_tcb, phys_tcb, idle_tcb;
static CPU_STK angle_stack[ANGLE_TASK_STACK_SIZE];
static CPU_STK throttle_stack[THROTTLE_TASK_STACK_SIZE];
static CPU_STK led_stack[LED_OUT_TASK_STACK_SIZE];
static CPU_STK lcd_stack[LCD_DISP_TASK_STACK_SIZE];
static CPU_STK phys_stack[PHYSICS_TASK_STACK_SIZE];
static CPU_STK idle_stack[IDLE_TASK_STACK_SIZE];

static OS_SEM btn_sem;
static OS_SEM tmr_throt_sem, tmr_phys_sem, tmr_lcd_sem;

static bool btn0_val, btn1_val;

static OS_Q phys_msg_q;
static OS_TMR tmr_throt, tmr_phys, tmr_lcd;
static OS_TICK throt_period = 1.2;              // will need tuning
static OS_TICK phys_period = 1;               // from config (tau)
static OS_TICK lcd_period = 2;                // will need tuning

/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/

static void angle_task(void *arg);
static void throttle_task(void *arg);
static void physics_task(void *arg);
static void led_out_task(void *arg);
static void lcd_disp_task(void *arg);
static void idle_task(void *arg);
void tmr_phys_cb(OS_TMR * p_tmr, void * p_arg);
void tmr_lcd_cb(OS_TMR * p_tmr, void * p_arg);
void tmr_throt_cb(OS_TMR * p_tmr, void * p_arg);

/***************************************************************************//**
 * Initialize application.
 ******************************************************************************/

/***************************************************************************//**
 * @brief
 *      Calls open functions to setup tasks.
 *
 * @details
 *      Called by the main function and then sets up the button, slider,
 *      led, and idle tasks.
 *
 * @note
 *      Calls task init, not task main.
 *
 ******************************************************************************/
void app_init(void)
{
  load_config();
  btn0_val = false;
  btn1_val = false;
  ipc_init();
  CAPSENSE_Init();
  srand(time(NULL));
  memlcd_app_init();
  init_fuel();
  init_win();
  init_angle();
  task_init();
}


void tmr_phys_cb(OS_TMR * p_tmr, void * p_arg){
  PP_UNUSED_PARAM(p_arg);
  PP_UNUSED_PARAM(p_tmr);

  RTOS_ERR err;
  OSSemPost(&tmr_phys_sem, OS_OPT_POST_ALL, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

void tmr_lcd_cb(OS_TMR * p_tmr, void * p_arg){
  PP_UNUSED_PARAM(p_arg);
  PP_UNUSED_PARAM(p_tmr);

  RTOS_ERR err;
  OSSemPost(&tmr_lcd_sem, OS_OPT_POST_ALL, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

void tmr_throt_cb(OS_TMR * p_tmr, void * p_arg){
  PP_UNUSED_PARAM(p_arg);
  PP_UNUSED_PARAM(p_tmr);

  RTOS_ERR err;
  OSSemPost(&tmr_throt_sem, OS_OPT_POST_ALL, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}


/***************************************************************************//**
 * @brief
 *      Sets up inter task communication structures
 *
 * @details
 *      Creates semaphores, OSflags, and OSTimer
 *
 *
 ******************************************************************************/
void ipc_init(void){
  RTOS_ERR err;

  // Create button semaphore
  OSSemCreate(&btn_sem,
              "Button Semaphore",
              0,
              &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTmrCreate(&tmr_throt,
              "OS Timer Throttle",
              0,                      // 0 delay
              throt_period,
              OS_OPT_TMR_PERIODIC,
              (OS_TMR_CALLBACK_PTR) tmr_throt_cb,
              NULL,
              &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSSemCreate(&tmr_throt_sem,
              "Throttle Timer Semaphore",
              0,
              &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));


  OSTmrCreate(&tmr_phys,
              "OS Timer Physics",
              0,                      // 0 delay
              phys_period,
              OS_OPT_TMR_PERIODIC,
              (OS_TMR_CALLBACK_PTR) tmr_phys_cb,
              NULL,
              &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));


  OSSemCreate(&tmr_phys_sem,
              "Physics Timer Semaphore",
              0,
              &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));


  OSTmrCreate(&tmr_lcd,
              "OS Timer LCD",
              0,                      // 0 delay
              lcd_period,
              OS_OPT_TMR_PERIODIC,
              (OS_TMR_CALLBACK_PTR) tmr_lcd_cb,
              NULL,
              &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));


  OSSemCreate(&tmr_lcd_sem,
              "LCD Timer Semaphore",
              0,
              &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));


  // Create Message Queue
  OS_MSG_QTY lim = 16;
  OSQCreate(&phys_msg_q,
            "PHYS Msg Q",
            lim,
            &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}


/***************************************************************************//**
 * @brief
 *      Sets up tasks
 *
 * @details
 *      Creates 6 tasks total
 *
 *
 ******************************************************************************/
void task_init(void){
  RTOS_ERR err;

  // Create Speed Task
  OSTaskCreate(&angle_tcb,
               "Angle Setpoint",
               angle_task,
               DEF_NULL,
               ANGLE_TASK_PRIO,
               &angle_stack[0],
               (ANGLE_TASK_STACK_SIZE / 10u),
               ANGLE_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  // Create Slider Task
  OSTaskCreate(&throttle_tcb,
               "Throttle",
               throttle_task,
               DEF_NULL,
               THROTTLE_TASK_PRIO,
               &throttle_stack[0],
               (THROTTLE_TASK_STACK_SIZE / 10u),
               THROTTLE_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  // Create LED Task
  OSTaskCreate(&led_tcb,
               "LED Out task",
               led_out_task,
               DEF_NULL,
               LED_OUT_TASK_PRIO,
               &led_stack[0],
               (LED_OUT_TASK_STACK_SIZE / 10u),
               LED_OUT_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  // Create LCD Task
  OSTaskCreate(&lcd_tcb,
               "LCD Display",
               lcd_disp_task,
               DEF_NULL,
               LCD_DISP_TASK_PRIO,
               &lcd_stack[0],
               (LCD_DISP_TASK_STACK_SIZE / 10u),
               LCD_DISP_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));


  // Create Monitor Task
  OSTaskCreate(&phys_tcb,
               "Physics Task",
               physics_task,
               DEF_NULL,
               PHYSICS_TASK_PRIO,
               &phys_stack[0],
               (PHYSICS_TASK_STACK_SIZE / 10u),
               PHYSICS_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  // Create IDLE Task
  OSTaskCreate(&idle_tcb,
               "Idle task",
               idle_task,
               DEF_NULL,
               IDLE_TASK_PRIO,
               &idle_stack[0],
               (IDLE_TASK_STACK_SIZE / 10u),
               IDLE_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}



/***************************************************************************//**
 * @brief
 *      Speed Task main function
 *
 * @details
 *      Updates speed depending on button input and button fifo
 *
 *
 ******************************************************************************/
static void angle_task(void *arg){
    PP_UNUSED_PARAM(arg);
    //uint32_t btns;

#ifdef tests_on
    run_tests();
#endif

    RTOS_ERR err;

    while (1){
        OSSemPend(&btn_sem, 0, OS_OPT_PEND_BLOCKING, (CPU_TS*)0, &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));


        if(get_gameover()){
            if(btn0_val || btn1_val){
                game_reset();
            }
            continue;
        }


        // Functions themselves have mutex lock
        if(btn0_val) angle_increment();
        if(btn1_val) angle_decrement();
    }
}



/***************************************************************************//**
 * @brief
 *      Direction Task main function
 *
 * @details
 *      updates direction based on slider position
 *      wakes periodically based on OStimer
 *
 *
 ******************************************************************************/
static void throttle_task(void *arg){
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    uint32_t pos;

    OSTmrStart(&tmr_throt, &err);
    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

    while (1){

        OSSemPend(&tmr_throt_sem, 0, OS_OPT_PEND_BLOCKING, (CPU_TS*)0, &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        CAPSENSE_Sense();
        pos = 0;
        if(CAPSENSE_getPressed(SENSE_LEFT)) pos = 1;    // Far Left
        if(CAPSENSE_getPressed(SENSE_LEFTM)) pos = 2;   // Middle Left

        if(CAPSENSE_getPressed(SENSE_RIGHT)) pos = 4;     // Far Right
        if(CAPSENSE_getPressed(SENSE_RIGHTM)) pos = 3;   // Middle right

        fuel_set(pos);

    }
}


/***************************************************************************//**
 * @brief
 *      LED Out Task main function
 *
 * @details
 *      Calls LED driver function to update LEDS based on violation flags
 *
 ******************************************************************************/
static void led_out_task(void *arg){
    PP_UNUSED_PARAM(arg);
    // Initialize gpio for led task
    gpio_led_open();

//    RTOS_ERR err;
//    bool led0 = false, led1 = false;

//    while(1){

//        if(led0) GPIO_PinOutSet(LED0_port, LED0_pin);
//        else GPIO_PinOutClear(LED0_port, LED0_pin);
//
//        if(led1) GPIO_PinOutSet(LED1_port, LED1_pin);
//        else GPIO_PinOutClear(LED1_port, LED1_pin);
//    }
}



/***************************************************************************//**
 * @brief
 *      LCD Task, Displays speed and direction to LCD
 *
 * @details
 *      calls lcd functions from memlcd_app
 *
 ******************************************************************************/
static void lcd_disp_task(void *arg){
  PP_UNUSED_PARAM(arg);
  RTOS_ERR err;
  ROCKET_STRUCT rocket;
  POLYGON_STRUCT points;

  OSTmrStart(&tmr_lcd, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  while (1){
      OSSemPend(&tmr_lcd_sem, 0, OS_OPT_PEND_BLOCKING, (CPU_TS*)0, &err);
      EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

      rocket = get_rocket();
      get_vertices(&points, &rocket);
      disp_rocket(&points);


  }
}



/***************************************************************************//**
 * @brief
 *      Monitor task checks for violations
 *
 * @details
 *      woken by OSFlags for speed or direction update
 *
 ******************************************************************************/
static void physics_task(void *arg){
  PP_UNUSED_PARAM(arg);
  RTOS_ERR err;

  physics_init();


#ifdef tests_on
    OSTimeDly(TEST_DELAY, OS_OPT_TIME_DLY, &err);
    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
#endif


  OSTmrStart(&tmr_phys, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  while(1){
      OSSemPend(&tmr_phys_sem, 0, OS_OPT_PEND_BLOCKING, (CPU_TS*)0, &err);
      EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

      if(get_gameover()) continue;
      physics_engine();

  }

}


/***************************************************************************//**
 * @brief
 *      Idle Task main function
 *
 * @details
 *      Enters sleep mode while idle.
 *
 ******************************************************************************/
static void idle_task(void *arg){
    PP_UNUSED_PARAM(arg);
     while (1){
         EMU_EnterEM1();
     }
}



/***************************************************************************//**
 * Callback on button change.
 *
 * This function overrides a weak implementation defined in the simple_button
 * module. It is triggered when the user activates one of the buttons.
 *
 ******************************************************************************/
void sl_button_on_change(const sl_button_t *handle)
{
  RTOS_ERR err;
  if (&BUTTON_INSTANCE_0 == handle) {
      if (sl_button_get_state(handle) == SL_SIMPLE_BUTTON_PRESSED) btn0_val = true;
      else btn0_val = false;
  }

  else if (&BUTTON_INSTANCE_1 == handle) {
      if (sl_button_get_state(handle) == SL_SIMPLE_BUTTON_PRESSED) btn1_val = true;
      else btn1_val = false;
  }

  OSSemPost(&btn_sem, OS_OPT_POST_ALL, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

