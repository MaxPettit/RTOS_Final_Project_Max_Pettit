/*
 * ipc.h
 *
 *  Created on: Oct 3, 2021
 *      Author: maxpettit
 */

#ifndef SRC_HEADER_FILES_IPC_H_
#define SRC_HEADER_FILES_IPC_H_


enum monitor_flags{
  SPEEDUPDATE = 1,          // 0b0001
  DIRUPDATE = 2             // 0b0010
};

enum led_flags{
  SPEEDVIOLATION = 1,          // 0b0001
  DIRVIOLATION = 2             // 0b0010
};


#endif /* SRC_HEADER_FILES_IPC_H_ */
