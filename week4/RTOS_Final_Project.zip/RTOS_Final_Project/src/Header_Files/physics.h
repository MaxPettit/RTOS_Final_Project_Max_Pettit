/*
 * physics.h
 *
 *  Created on: Nov 5, 2021
 *      Author: maxpettit
 */

#ifndef SRC_HEADER_FILES_PHYSICS_H_
#define SRC_HEADER_FILES_PHYSICS_H_

#include "em_emu.h"
#include "os.h"
#include "brd_config.h"
#include "rocket.h"
#include <time.h>
#include "game.h"

#define   YSTART    10
#define   LANDING_RANGE 12
#define   RAND_RANGE    50
#define   FUEL_WEIGHT   10

typedef enum{
  option0
}CONFIG_OPTION;

typedef struct{
  uint32_t version;
  uint32_t gravity;
  uint32_t vehicle_mass;
  int xmin;
  int xmax;
  CONFIG_OPTION option;
  uint32_t max_thrust;
  uint32_t init_fuel;
  uint32_t maxspeedx;
  uint32_t maxspeedy;
  uint32_t black_acc;
  uint32_t black_dur;
  uint32_t conv_eff;      //[N/kg] near 4000
  uint32_t tau_phys;
  int xvel;
  int yvel;
  int init_xpos;
  int angle_quanta;
}CONFIG_STRUCT;


void load_config(void);
CONFIG_STRUCT *get_config(void);
uint32_t get_ticks(void);

void physics_init(void);
void physics_engine(void);
int calc_thrust(int fuel_rate);
bool get_blackout(int thrust);
void game_reset(void);

#endif /* SRC_HEADER_FILES_PHYSICS_H_ */
