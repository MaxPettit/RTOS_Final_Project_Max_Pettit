/*
 * brd_config.h
 *
 *  Created on: Sep 3, 2021
 *      Author: maxpettit
 */

#ifndef HEADER_FILES_BRD_CONFIG_H_
#define HEADER_FILES_BRD_CONFIG_H_

#define LAB2_USE_INTERRUPT    true

/* Button Config */
#define BTN0_PIN        6u
#define BTN1_PIN        7u
#define BTN_PORT        gpioPortF
#define BTN0            0
#define BTN1            1

/* LED Config */
// LED 0 pin is
#define LED0_port       gpioPortF
#define LED0_pin        4u
#define LED0_default    false   // Default false (0) = off, true (1) = on

// LED 1 pin is
#define LED1_port       gpioPortF
#define LED1_pin        5u
#define LED1_default    false   // Default false (0) = off, true (1) = on

/* CAPSENSE Config */
#define SENSE_LEFT      0
#define SENSE_LEFTM     1
#define SENSE_RIGHTM    2
#define SENSE_RIGHT     3


#endif /* HEADER_FILES_BRD_CONFIG_H_ */
