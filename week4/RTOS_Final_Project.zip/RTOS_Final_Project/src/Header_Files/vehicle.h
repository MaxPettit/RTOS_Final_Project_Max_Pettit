/*
 * vehicle.h
 *
 *  Created on: Oct 15, 2021
 *      Author: maxpettit
 */

#ifndef SRC_HEADER_FILES_VEHICLE_H_
#define SRC_HEADER_FILES_VEHICLE_H_

#include "fifo.h"
#include "em_emu.h"
#include "os.h"
#include "brd_config.h"

void vehicle_init(void);
void fifo_push(bool btn0, bool btn1);
uint32_t fifo_read(void);
void increment_speed(void);
void decrement_speed(void);

uint32_t read_speed(void);
uint32_t read_time_held(void);



#endif /* SRC_HEADER_FILES_VEHICLE_H_ */
