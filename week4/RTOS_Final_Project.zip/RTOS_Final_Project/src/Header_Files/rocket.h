/*
 * rocket.h
 *
 *  Created on: Nov 3, 2021
 *      Author: maxpettit
 */

#ifndef SRC_HEADER_FILES_ROCKET_H_
#define SRC_HEADER_FILES_ROCKET_H_

#include "em_emu.h"
#include "os.h"
#include "brd_config.h"
#include "em_assert.h"
#include "glib.h"
#include "dmd.h"
#include "math.h"
#include "memlcd_app.h"
#include "game.h"

#define   ANGLE_DELTA       15
#define   PI                3.1416


#define   SHIP_SIDE_LEN     20
#define   SHIP_HEIGHT       12
#define   SHIP_HLF_WIDTH    16
#define   SHIP_NUM_PTS      3

typedef enum {
  Q_THRUST,
  Q_ACCELERATION
} MESSAGE_TYPE;

typedef struct{
  int32_t x_loc;     // 0 <= x_loc
  int32_t y_loc;     // 0 <= y_loc
  int angle;          // -180<= angle <= 180
} ROCKET_STRUCT;


// Defined as a struct in case more elements
// need to be added later in project
typedef struct{
  int angle;
} ANGLE_STRUCT;


// Defined as a struct in case more elements
// need to be added later in project
typedef struct{
  int fuel_rate;
} FUEL_STRUCT;


typedef struct{
  int32_t vf_x;
  int32_t vf_y;
  int32_t vL_x;
  int32_t vL_y;
  int32_t vR_x;
  int32_t vR_y;
} POLYGON_STRUCT;

void init_rocket(void);
void init_quanta(int quanta);
void init_angle(void);
void init_fuel(void);
void angle_increment(void);
void angle_decrement(void);
int angle_get(void);
void angle_set(int angle);
void fuel_set(uint32_t pos);
int fuel_get(void);
void get_vertices(POLYGON_STRUCT * poly, ROCKET_STRUCT *rocket);
void pwm_create(uint32_t select, uint32_t freq, uint32_t duty, OS_TMR_CALLBACK_PTR freq_cb, OS_TMR_CALLBACK_PTR duty_cb);
void disp_rocket(POLYGON_STRUCT * poly);
void set_rocket(ROCKET_STRUCT *input);
ROCKET_STRUCT get_rocket(void);
void disp_win(bool win);

#endif /* SRC_HEADER_FILES_ROCKET_H_ */
