/*
 * game.h
 *
 *  Created on: Nov 16, 2021
 *      Author: maxpettit
 */

#ifndef SRC_HEADER_FILES_GAME_H_
#define SRC_HEADER_FILES_GAME_H_

#include "em_emu.h"
#include "os.h"
#include "brd_config.h"
#include "em_assert.h"

bool get_gameover(void);
void set_gameover(bool over);
bool get_win(void);
void set_win(bool input);
void init_win(void);


#endif /* SRC_HEADER_FILES_GAME_H_ */
