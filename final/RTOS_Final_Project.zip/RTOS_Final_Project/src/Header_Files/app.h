/***************************************************************************//**
 * @file
 * @brief Top level application functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

#ifndef APP_H
#define APP_H

#include <stdio.h>
#include <string.h>
#include "cmu.h"
#include "gpio.h"
#include "os.h"
#include "em_emu.h"
#include "capsense.h"
#include "brd_config.h"
#include "memlcd_app.h"
#include "sl_board_control.h"
#include "sl_simple_button_instances.h"
#include "game.h"
#include "unit_test.h"

#define ANGLE_TASK_STACK_SIZE      512
#define ANGLE_TASK_PRIO            19

#define THROTTLE_TASK_STACK_SIZE      512
#define THROTTLE_TASK_PRIO            20

#define LED_OUT_TASK_STACK_SIZE     512
#define LED_OUT_TASK_PRIO           22

#define LCD_DISP_TASK_STACK_SIZE     512
#define LCD_DISP_TASK_PRIO           24

#define PHYSICS_TASK_STACK_SIZE        512
#define PHYSICS_TASK_PRIO              15

#define IDLE_TASK_STACK_SIZE        64
#define IDLE_TASK_PRIO              30

#define SLIDE_XL                 (0x1UL << 3)
#define SLIDE_L                  (0x1UL << 2)
#define SLIDE_R                  (0x1UL << 1)
#define SLIDE_XR                 (0x1UL << 0)

#ifndef BUTTON_INSTANCE_0
#define BUTTON_INSTANCE_0   sl_button_btn0
#endif

#ifndef BUTTON_INSTANCE_1
#define BUTTON_INSTANCE_1   sl_button_btn1
#endif

#define TIMEOUT     3000

/***************************************************************************//**
 * Initialize application.
 ******************************************************************************/
void app_init(void);
void ipc_init(void);
void task_init(void);


#endif  // APP_H
