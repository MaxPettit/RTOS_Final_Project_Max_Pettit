/***************************************************************************//**
 * @file memlcd_app.c
 * @brief Memory Liquid Crystal Display (LCD) example functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/
#include <stdio.h>

#include "sl_board_control.h"
#include "sl_simple_button_instances.h"
#include  "memlcd_app.h"
#include "em_assert.h"
#include "glib.h"
#include "dmd.h"
#include "os.h"

/*******************************************************************************
 *******************************   DEFINES   ***********************************
 ******************************************************************************/

#ifndef TASK_STACK_SIZE
#define TASK_STACK_SIZE      64
#endif

#ifndef TASK_PRIO
#define TASK_PRIO            20
#endif

#ifndef BUTTON_INSTANCE_0
#define BUTTON_INSTANCE_0   sl_button_btn0
#endif

#ifndef BUTTON_INSTANCE_1
#define BUTTON_INSTANCE_1   sl_button_btn1
#endif

/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/


static GLIB_Context_t glibContext;
static int currentLine = 0;

/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/


/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/

/***************************************************************************//**
 * Initialize example.
 ******************************************************************************/

/***************************************************************************//**
 * @brief
 *      initialize lcd, from SI labs example
 *
 ******************************************************************************/
void memlcd_app_init(void)
{
  uint32_t status;

  /* Enable the memory lcd */
  status = sl_board_enable_display();
  EFM_ASSERT(status == SL_STATUS_OK);

  /* Initialize the DMD support for memory lcd display */
  status = DMD_init(0);
  EFM_ASSERT(status == DMD_OK);

  /* Initialize the glib context */
  status = GLIB_contextInit(&glibContext);
  EFM_ASSERT(status == GLIB_OK);

  glibContext.backgroundColor = White;
  glibContext.foregroundColor = Black;

  /* Fill lcd with background color */
  GLIB_clear(&glibContext);

  /* Use Narrow font */
  GLIB_setFont(&glibContext, (GLIB_Font_t *) &GLIB_FontNarrow6x8);

  DMD_updateDisplay();
}


/***************************************************************************//**
 * @brief
 *      Clear LCD
 *
 ******************************************************************************/
void lcd_clear(void){
  currentLine = 1;
  GLIB_clear(&glibContext);
}


/***************************************************************************//**
 * @brief
 *      Print text to LCD on new line
 *
 * @details
 *      Display is not updated until update_lcd called
 *
 ******************************************************************************/
void lcd_print_text(char * str){
  GLIB_drawStringOnLine(&glibContext,
                        str,
                        currentLine++,
                        GLIB_ALIGN_LEFT,
                        5,
                        5,
                        true);
//  DMD_updateDisplay();
}


/***************************************************************************//**
 * @brief
 *      Update LCD. Flushes pending changes to display
 *
 ******************************************************************************/
void update_lcd(void){
  DMD_updateDisplay();

}

void lcd_landing(void){
  GLIB_drawLineH(&glibContext, 0, 125, 200);
  GLIB_drawCircle(&glibContext, DISP_CENTER, 128, 7);
}

void lcd_polygon(uint32_t num_points, const int32_t *points){
//  GLIB_drawPolygon(&glibContext, num_points, points);
  GLIB_drawPolygonFilled(&glibContext, num_points, points);
}

