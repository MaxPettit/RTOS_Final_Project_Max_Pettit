/*
 * game.c
 *
 *  Created on: Nov 16, 2021
 *      Author: maxpettit
 */


#include "game.h"

static bool gameover;
static bool win;

static OS_MUTEX OVER_LOCK;

void init_win(void){
  RTOS_ERR err;
  OSMutexCreate(&OVER_LOCK,
                "Gameover Mutex",
                &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  gameover = false;
  win = false;
}

bool get_gameover(void){
  RTOS_ERR err;
  bool temp;
  OSMutexPend (&OVER_LOCK,
               0,
               OS_OPT_PEND_BLOCKING,
               (CPU_TS *)0,
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  temp = gameover;

  OSMutexPost (&OVER_LOCK,
               OS_OPT_POST_NONE,
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  return temp;

}


void set_gameover(bool over){

  RTOS_ERR err;
  OSMutexPend (&OVER_LOCK,
               0,
               OS_OPT_PEND_BLOCKING,
               (CPU_TS *)0,
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  gameover = over;

  OSMutexPost (&OVER_LOCK,
               OS_OPT_POST_NONE,
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

// Does not need mutex protection
// LCD task only accesses after game is over
// LCD only task to access
bool get_win(void){
  return win;

}

// Does not need mutex protection
// Physics task only accesses before game is over
// LCD task only accesses after game is over
void set_win(bool input){

  win = input;

}

